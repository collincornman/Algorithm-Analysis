#!/bin/bash
python pA.py "$@"