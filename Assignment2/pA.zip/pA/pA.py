import sys
'''
a = int(sys.argv[1])
exp = int(sys.argv[3])
mod = int(sys.argv[2])
'''
with open("input002.txt") as f:
    t = f.readline()
bits = list()
bits = t.split(" ")
a = 83
exp = 10000
mod = 31

xp = bin(exp)[2:]
s = 0

for x in range(0, len(xp)):
    val=1
    if x == len(xp)-1:
        break
    elif int(xp[x]) == 1:
        p = (len(xp)-1)-x

        sq = (a**2) % mod
        if (p % 2) == 0:
            p = 2**p
            while p >= 2:
                val *= sq
                p /= 2
            s += (val % mod)
        else:
            p -= 1
            p = 2**p
            while p>=2:
                val *= sq
                p /= 2
            val += (a % mod)
            s += (val % mod)
s = (s % mod)
print("" + str(a) + " ^ " + str(exp) + " mod " + str(mod) + " = "+ str(s) + "")
