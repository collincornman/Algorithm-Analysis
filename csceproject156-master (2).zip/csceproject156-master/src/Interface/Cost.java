package Interface;

public interface Cost {

	public double getCostt();
	
}
