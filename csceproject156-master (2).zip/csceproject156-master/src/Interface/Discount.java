package Interface;

public interface Discount {
	public double getDiscount();
}
