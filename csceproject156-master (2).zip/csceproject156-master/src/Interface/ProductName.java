package Interface;

public interface ProductName {
	public String getProductName();
}
