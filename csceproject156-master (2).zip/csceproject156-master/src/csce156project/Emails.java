package csce156project;

public class Emails {

	private String[] emails;

	public String[] getMails() {
		return emails;
	}

	public void setMails(String[] emails) {
		this.emails = emails;
	}

	public Emails(String[] emails) {
		super();
		this.emails = emails;
	}
	
//	public Emails getMail(String[] mails) {
//		this.mails = mails;
//		int i =0;
//		if(i < mails.length ) {
//			
//		}
//		
//		
//		return null;
//	}
	
}
